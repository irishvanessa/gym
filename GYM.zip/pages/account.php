<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
    </head>
    <body>
        <?php include "../component/topbar.php"; ?>


        <form action="../activity/login.php" method="POST">
            <h1>Username</h1>
            <input name="username" type="text">
            <h1>Password</h1>
            <input name="password" type="password">
            <input type="submit">
        </form>
        <a href="./signup.php">Sign up</a>
    </body>
</html>
